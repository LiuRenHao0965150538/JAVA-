package �@�~�T;

import java.util.Random;

public class �ĤG�D 
{
	public static void main(String args []) 
	{
		int sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8,sum9,sum10,sum11,sum12,max;
		
		int m,n;
		int [][]NoTwoArray=RandomTwoArray(4,5);
		for(m=0;m<=3;m++) 
		{
			for(n=0;n<=4;n++) 
			{
				System.out.printf("\t%2d",NoTwoArray[m][n]);
		}
			System.out.printf("\n");
	}
		sum1=NoTwoArray[0][0]+NoTwoArray[0][1]+NoTwoArray[1][0]+NoTwoArray[1][1];
		sum2=NoTwoArray[0][1]+NoTwoArray[0][2]+NoTwoArray[1][1]+NoTwoArray[1][2];
		sum3=NoTwoArray[0][2]+NoTwoArray[0][3]+NoTwoArray[1][2]+NoTwoArray[1][3];
		sum4=NoTwoArray[0][3]+NoTwoArray[0][4]+NoTwoArray[1][3]+NoTwoArray[1][4];
		sum5=NoTwoArray[1][0]+NoTwoArray[1][1]+NoTwoArray[2][0]+NoTwoArray[2][1];
		sum6=NoTwoArray[1][1]+NoTwoArray[1][2]+NoTwoArray[2][1]+NoTwoArray[2][2];
		sum7=NoTwoArray[1][2]+NoTwoArray[1][3]+NoTwoArray[2][2]+NoTwoArray[2][3];
		sum8=NoTwoArray[1][3]+NoTwoArray[1][4]+NoTwoArray[2][3]+NoTwoArray[2][4];
		sum9=NoTwoArray[2][0]+NoTwoArray[2][1]+NoTwoArray[3][0]+NoTwoArray[3][1];
		sum10=NoTwoArray[2][1]+NoTwoArray[2][2]+NoTwoArray[3][1]+NoTwoArray[3][2];
		sum11=NoTwoArray[2][2]+NoTwoArray[2][3]+NoTwoArray[3][2]+NoTwoArray[3][3];
		sum12=NoTwoArray[2][3]+NoTwoArray[2][4]+NoTwoArray[3][3]+NoTwoArray[3][4];
	max=sum1;
	if(sum2>max)max=sum2;
	else if(sum3>max)max=sum3;
	else if(sum4>max)max=sum4;
	else if(sum5>max)max=sum5;
	else if(sum6>max)max=sum6;
	else if(sum7>max)max=sum7;
	else if(sum8>max)max=sum8;
	else if(sum9>max)max=sum10;
	else if(sum10>max)max=sum10;
	else if(sum11>max)max=sum11;
	else max=sum12;
	System.out.printf("%s%d%n", "�̤j�l�x�}�`�X��",max);
	}
	public static int [] [] RandomTwoArray(int x , int y)
	{
	Random RN=new Random();
		int i, j;
	int [ ] [ ] tmp=new int[x][y];
	for(i=0;i<=3;i++)  
	{
		for( j=0;j<=4;j++) 
		{
		tmp[i][j]=RN.nextInt(26)-13;	
		}
	}
	return tmp;
	}

	
}
