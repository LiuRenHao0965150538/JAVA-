package �@�~�T;
import java.util.*;
public class �Ĥ@�D
{
 
public static void main(String args []) 
{
	int m,n;
	int [][]NoOneArray=RandomOneArray(5,5);
	for(m=0;m<=4;m++) 
	{
		for(n=0;n<=4;n++) 
		{
			System.out.printf("\t%2d",NoOneArray[m][n]);
	}
		System.out.printf("\n");
}
	
	
}
public static int [] [] RandomOneArray(int x , int y)
{
int num=1;
boolean  bol=true;
	int i, j;
int [ ] [ ] tmp=new int[x][y];
for(i=0;i<=4;i++)  
{
	for( j=0;j<=4;j++) 
	{
	if(j%2!=0&&bol||j%2==0&&!bol) 
	{
	tmp[i][j]=0;	
	}
	else 
	{
		tmp[i][j]=	num;
		num+=1;	
	}
	}
	bol=!bol;
}
return tmp;
}

}
