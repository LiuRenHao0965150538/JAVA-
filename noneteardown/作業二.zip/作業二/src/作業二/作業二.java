package �@�~�G;
import java.util.Random;
public class �@�~�G
{
	public static int[][] generateArray(int x, int y) {
		int[][] tmp = new int[x][y];
		Random rnd = new Random();
		for(int i=0;i<tmp.length;i++) {
			for(int j=0;j<tmp[i].length;j++) {
				tmp[i][j] = rnd.nextInt(101);
			}
		}	
		return tmp;
	}
	
	public static void printArray(int[][] tmp) {
		for(int i=0;i<tmp.length;i++) {
			for(int j=0;j<tmp[i].length;j++) {
				System.out.print(tmp[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	public static int[][] addArray(int[][] x, int[][] y) {
		int[][] tmp = new int[x.length][x[0].length];
		
		for(int i=0;i<x.length;i++) {
			for(int j=0;j<x[i].length;j++) {
				tmp[i][j] = x[i][j] + y[i][j];
			}
		}
		
		
		return tmp;
	}
	
	public static int[][] subArray(int[][] x, int[][] y) {
		int[][] tmp = new int[x.length][x[0].length];
		
		for(int i=0;i<x.length;i++) {
			for(int j=0;j<x[i].length;j++) {
				tmp[i][j] = x[i][j] - y[i][j];
			}
		}
		
		return tmp;
	}
	
	public static int[][] mulArray(int[][] x, int[][] y) {
		int[][] tmp = new int[x.length][y[0].length];
		
		/*
		 
		 tmp[0][0]=x[0][0]*y[0][0]+x[0][1]*y[1][0]	tmp[0][1]=x[0][0]*y[0][1]+x[0][1]*y[1][1]
		 
		 tmp[1][0]=x[1][0]*y[0][0]+x[1][1]*y[1][0]	tmp[1][1]=x[1][0]*y[0][1]+x[1][1]*y[1][1]
		 
		 */
		
		
		for(int i=0; i<x.length;i++) {
			for(int j=0;j<y[0].length;j++) {
			    for(int k=0; k<x[0].length;k++) {
			    	tmp[i][j] = tmp[i][j] + x[i][k] * y[k][j];
			    }
				//tmp[i][j] = x[i][0] * y[0][j] + x[i][1] * y[1][j];
				
				
			}
		}
		
		return tmp;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
					  
		int[][] x = generateArray(2, 2);
		int[][] y = generateArray(2, 2);
				
		System.out.println("X �}�C : ");
		printArray(x);
		System.out.println();
		
		System.out.println("Y �}�C : ");
		printArray(y);
		System.out.println();
		
		System.out.println("X+Y : ");
		printArray(addArray(x, y));
		System.out.println();
		
		System.out.println("X-Y : ");
		printArray(subArray(x, y));
		System.out.println();
		
		System.out.println("X*Y : ");
		printArray(mulArray(x, y));
		System.out.println();
		
	}

}
