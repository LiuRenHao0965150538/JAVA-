package �@�~�G;

import java.util.Random;

public class Fuctions 
{
public static void sum(int x[][],int y[][])
{
int sum[][]=new int[2][2];
sum[0][0]=x[0][0]+y[0][0];
sum[0][1]=x[0][1]+y[0][1];
sum[1][0]=x[1][0]+y[1][0];
sum[0][1]=x[0][1]+y[0][1];
System.out.print( "1."+sum[0][0]+sum[0][1]);
System.out.print( "  "+sum[1][0]+sum[1][1]);
}
public static void min(int x[][],int y[][]) 
{
	int [][]min=new int [2][2];
	min[0][0]=x[0][0]-y[0][0];
	min[0][1]=x[0][1]-y[0][1];
    min[1][0]=x[1][0]-y[1][0];
	min[0][1]=x[0][1]-y[0][1];
	System.out.print( "2."+min[0][0]+min[0][1]);
	System.out.print( "  "+min[1][0]+min[1][1]);
}
public static void mul(int x[][],int y[][]) 
{
int [][]mul=new int [2][2];
	mul[0][0]=(x[0][0]*y[0][0]+x[0][1]*y[1][0]);
	mul[0][1]=(x[0][0]*y[0][1]+x[0][1]*y[1][1]);
	mul[1][0]=(x[1][0]*y[0][1]+x[1][1]*y[1][0]);
	mul[1][1]=(x[1][0]*y[0][1]+x[1][1]*y[1][1]);
	System.out.print( "3."+mul[0][0]+mul[0][1]);
	System.out.print( "  "+mul[1][0]+mul[1][1]);
}
public static int [] [] generateArray(int x , int y)
{
Random RN=new Random();
	int i, j;
int [ ] [ ] tmp=new int[x][y];
for(i=0;i<tmp.length;i++)  
{
	for( j=0;j<1;j++) 
	{
	tmp[i][j]=RN.nextInt(101);	
	}
}
return tmp;
}
}
