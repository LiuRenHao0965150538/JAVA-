package �@�~�|;

public class �Ĥ@�D 
{
public static void main(String args[]) 
{
int [][]	x=generateArray(5);
printArray(x);
}
public static int[][]generateArray(int n)
{
	//java.util.Random rnd=new java.util.Random();
int tmp[][]=new int[n+1][n+1];
int i,j,key;
for( i = 0, j = (n + 1) / 2, key = 1; key <= n*n; key++) { 
    if((key % n) == 1) i++; 
    else { 
    	i--; j++;
    	} 

    if(i == 0) i = n; 
    if(j > n) j = 1; 

    tmp[i][j] = key; 
}

int[][] matrix = new int[n][n];

for(int k = 0; k < matrix.length; k++) {
   for(int l = 0; l < matrix[0].length; l++) {
       matrix[k][l] = tmp[k+1][l+1];
   }
}
return tmp;
}
public static void printArray(int tmp[][]) 
{
int i,j;
for(i=0;i<tmp.length;i++) 
{
for(j=0;j<tmp[i].length;j++) 
{
System.out.print(tmp[i][j]+"\t");	
}
	System.out.println();	
}
}

}
