package �@�~�|;

public class �Ĥ@�D 
{
public static void main(String args[]) 
{
int [][]	x=Fuctions.generateArray(5);
Fuctions.printArray(x);
}


}
