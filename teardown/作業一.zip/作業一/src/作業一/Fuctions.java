package �@�~�@;

public class Fuctions
{
	static int DIGITS=4;
	static int []question=new int[DIGITS];
	static int[]your_answer=new int[DIGITS];
	public static void generateQuestion() 
	{
	int m,n;
	boolean is_repeat;
	question[0]=(int)(Math.random()*9)+1;
	for(m=1;m<DIGITS;m++) 
	{
	question[m]=(int)(Math.random()*10);
	is_repeat=false;
	for(n=0;n<m;n++) 
	{
		if(question[m]==question[n]) 
		{
		is_repeat=true;
		break;
		}
	}
	while(is_repeat);
	}
	System.out.print(String.format("%d%d%d%d\n", question[0],question[1],question[2],question[3]));
	}
	public static void guess(int your_answer[]) 
	{
	int vaule,n;
	java.util.Scanner scan=new java.util.Scanner(System.in);
	vaule=scan.nextInt();
	for(n=DIGITS-1;n>=0;n--) 
	{
	your_answer[n]=vaule%10;
	vaule/=10;
	}
	}
	public static boolean compare(int your_answer[]) 
	{
	int a_count=0,b_count=0,m,n;
	for(m=0;m<DIGITS;m++) 
	{
	if(your_answer[m]==question[m]) 
	{
	a_count++;	
	}
	else 
	{
	for(n=0;n<DIGITS;n++) 
	{
	if(your_answer[m]==question[n]&&n!=m) 
	{
	b_count++;
	break;
	}
	}
	}
	}
	System.out.print(a_count+"A"+b_count+"B");
	if(a_count==DIGITS)return true;
	else 
	{
		 System.out.println("�A�դ@���I");
	     return false;
	}
	}
}
