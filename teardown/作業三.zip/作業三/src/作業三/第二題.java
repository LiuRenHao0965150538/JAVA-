package �@�~�T;

import java.util.Random;

public class �ĤG�D 
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] a =Fuctions.generateArray(4, 5);
		Fuctions.compare(a);
		

	}
	
}
