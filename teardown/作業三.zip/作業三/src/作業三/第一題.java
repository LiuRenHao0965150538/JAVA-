package �@�~�T;
public class �Ĥ@�D
{
 
public static void main(String args []) 
{
	int m,n;
	int [][]NoOneArray=Fuctions.RandomOneArray(5,5);
	for(m=0;m<=4;m++) 
	{
		for(n=0;n<=4;n++) 
		{
			System.out.printf("\t%2d",NoOneArray[m][n]);
	}
		System.out.printf("\n");
}
	
	
}


}
