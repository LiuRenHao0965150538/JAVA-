package �@�~�T;

import java.util.Random;

public class Fuctions
{
	public static int [] [] RandomOneArray(int x , int y)
	{
	int num=1;
	boolean  bol=true;
		int i, j;
	int [ ] [ ] tmp=new int[x][y];
	for(i=0;i<=4;i++)  
	{
		for( j=0;j<=4;j++) 
		{
		if(j%2!=0&&bol||j%2==0&&!bol) 
		{
		tmp[i][j]=0;	
		}
		else 
		{
			tmp[i][j]=	num;
			num+=1;	
		}
		}
		bol=!bol;
	}
	return tmp;
	}
public static int[][]generateArray(int x,int y)
{
	Random rnd = new Random();
	int[][] a = new int[x][y];
	
	for(int i=0;i<a.length;i++) {
		for(int j=0;j<a[i].length;j++) {	
			a[i][j] = rnd.nextInt(25)+1-13;
		}
	}
	return a;
}
public static void compare(int a[][]) 
{
	int max = a[0][0] + a[0][1] + a[1][0] + a[1][1];
	for(int i=0;i<=a.length-2;i++) {
		for(int j=0;j<=a[i].length-2;j++) {	
			int sum= a[i][j] + a[i][j+1] + a[i+1][j] + a[i+1][j+1];
			/*
			int sum = 0;
			for(int ii =i;ii<2;ii++) {
				for(int jj=j;jj<2;jj++) {
					sum = sum + a[ii][jj];
				}
			}*/
			
			if(max < sum) {
				max = sum;
			}
		}
	}
	System.out.println("�̤j�� : " + max);
}
}
