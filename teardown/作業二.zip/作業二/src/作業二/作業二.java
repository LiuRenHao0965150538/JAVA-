package �@�~�G;

public class �@�~�G
{
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
					  
		int[][] x = Fuctions.generateArray(2, 2);
		int[][] y = Fuctions.generateArray(2, 2);
				
		System.out.println("X �}�C : ");
		Fuctions.printArray(x);
		System.out.println();
		
		System.out.println("Y �}�C : ");
		Fuctions.printArray(y);
		System.out.println();
		
		System.out.println("X+Y : ");
		Fuctions.printArray(Fuctions.addArray(x, y));
		System.out.println();
		
		System.out.println("X-Y : ");
		Fuctions.printArray(Fuctions.subArray(x, y));
		System.out.println();
		
		System.out.println("X*Y : ");
		Fuctions.printArray(Fuctions.mulArray(x, y));
		System.out.println();
		
	}

}
